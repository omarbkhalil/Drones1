var annotated_dup =
[
    [ "Canvas", "class_canvas.html", "class_canvas" ],
    [ "Drone", "class_drone.html", "class_drone" ],
    [ "MainWindow", "class_main_window.html", "class_main_window" ],
    [ "Vector2D", "class_vector2_d.html", "class_vector2_d" ]
];