var searchData=
[
  ['takeoffimg_0',['takeoffImg',['../class_drone.html#a19add27702d2136f4d8f135277e12905',1,'Drone']]],
  ['takeoffspeed_1',['takeoffSpeed',['../class_drone.html#aa702eec241419c8360b51b80d6f29286',1,'Drone']]],
  ['timer_2',['timer',['../class_main_window.html#a356578805ed1248a7f2807434cb0e5ee',1,'MainWindow']]]
];
