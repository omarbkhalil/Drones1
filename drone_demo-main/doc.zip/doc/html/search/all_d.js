var searchData=
[
  ['paintevent_0',['paintEvent',['../class_canvas.html#a743fefef4af18260e8d56d95f92618aa',1,'Canvas::paintEvent()'],['../class_drone.html#a6d7cda9ed3d1a173f107bfef3a635a90',1,'Drone::paintEvent(QPaintEvent *) override']]],
  ['position_1',['position',['../class_drone.html#a1c4e77ec65b47ddaae2a0e2d29f5ea6a',1,'Drone']]],
  ['power_2',['power',['../class_drone.html#a1eba81b4e971f830fc498a51345d1248',1,'Drone']]],
  ['powerconsumption_3',['powerConsumption',['../class_drone.html#ac7d3282ce0c3400891283566e205dfa2',1,'Drone']]],
  ['powerpb_4',['powerPB',['../class_drone.html#a6786055bfa5b8345336b9518f8b24c07',1,'Drone']]]
];
