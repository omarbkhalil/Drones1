var searchData=
[
  ['dronestatus_0',['droneStatus',['../class_drone.html#aeab5eed0a5d06cc3968da277ad2671af',1,'Drone']]]
];
