var searchData=
[
  ['name_0',['name',['../class_drone.html#a72a835041f01fd55b8a315a6b811881b',1,'Drone']]],
  ['normalize_1',['normalize',['../class_vector2_d.html#a39a3335f33d7e9850b99e4498ba4d856',1,'Vector2D']]]
];
