var searchData=
[
  ['getazimut_0',['getAzimut',['../class_drone.html#a0535438871ce596434f05813be6fb2ce',1,'Drone']]],
  ['getname_1',['getName',['../class_drone.html#a5ccec19f2f37c7d6eeb087e48df247aa',1,'Drone']]],
  ['getposition_2',['getPosition',['../class_drone.html#af9acfa889406ec85fe8a43b1941d1bf3',1,'Drone']]],
  ['getpower_3',['getPower',['../class_drone.html#ac36d9fdaf2a0d2e31bb2924f04a0298f',1,'Drone']]],
  ['getstatus_4',['getStatus',['../class_drone.html#afafc9ba6fcff0a9b028594b6433adffc',1,'Drone']]],
  ['goalposition_5',['goalPosition',['../class_drone.html#a6c7fdb92102009fa20b5e21d7f0db884',1,'Drone']]]
];
