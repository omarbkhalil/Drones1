var searchData=
[
  ['takeoff_0',['takeoff',['../class_drone.html#aeab5eed0a5d06cc3968da277ad2671afad019f6ff2c3f203f876bb50bbaac2a0a',1,'Drone']]],
  ['takeoffimg_1',['takeoffImg',['../class_drone.html#a19add27702d2136f4d8f135277e12905',1,'Drone']]],
  ['takeoffspeed_2',['takeoffSpeed',['../class_drone.html#aa702eec241419c8360b51b80d6f29286',1,'Drone']]],
  ['timer_3',['timer',['../class_main_window.html#a356578805ed1248a7f2807434cb0e5ee',1,'MainWindow']]],
  ['turning_4',['turning',['../class_drone.html#aeab5eed0a5d06cc3968da277ad2671afa7653c975d1148f427139e926f79cf97d',1,'Drone']]]
];
