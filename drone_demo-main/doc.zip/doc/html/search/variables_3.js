var searchData=
[
  ['damping_0',['damping',['../class_drone.html#ab6681e09ecbb19bfb49378bdd3d1b112',1,'Drone']]],
  ['direction_1',['direction',['../class_drone.html#a38dc018619251cfc499cc0fb42844671',1,'Drone']]],
  ['dronecollisiondistance_2',['droneCollisionDistance',['../class_canvas.html#a5226f7b0b1190ff98adb88f2f79c9b5c',1,'Canvas']]],
  ['droneiconsize_3',['droneIconSize',['../class_canvas.html#a902077fa3f78b9de8c7de3fdb7f1d55a',1,'Canvas']]],
  ['droneimg_4',['droneImg',['../class_canvas.html#a44d7f1a477fa5d0f28f622f8e23166ec',1,'Canvas']]]
];
