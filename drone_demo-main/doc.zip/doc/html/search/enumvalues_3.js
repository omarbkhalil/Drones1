var searchData=
[
  ['takeoff_0',['takeoff',['../class_drone.html#aeab5eed0a5d06cc3968da277ad2671afad019f6ff2c3f203f876bb50bbaac2a0a',1,'Drone']]],
  ['turning_1',['turning',['../class_drone.html#aeab5eed0a5d06cc3968da277ad2671afa7653c975d1148f427139e926f79cf97d',1,'Drone']]]
];
