var class_main_window =
[
    [ "MainWindow", "class_main_window.html#a996c5a2b6f77944776856f08ec30858d", null ],
    [ "~MainWindow", "class_main_window.html#ae98d00a93bc118200eeef9f9bba1dba7", null ],
    [ "on_actionQuit_triggered", "class_main_window.html#aa68eba140c2cf5c1cd2b4bd81337fa83", null ],
    [ "update", "class_main_window.html#a128f71880d4b9683149023fc46fcc9f8", null ],
    [ "elapsedTimer", "class_main_window.html#afbd1d4920f59a85049eac42e281b4d80", null ],
    [ "mapDrones", "class_main_window.html#a6621f2696f413932fc1175b57499aa91", null ],
    [ "timer", "class_main_window.html#a356578805ed1248a7f2807434cb0e5ee", null ],
    [ "ui", "class_main_window.html#a35466a70ed47252a0191168126a352a5", null ]
];