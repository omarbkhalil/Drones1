var class_canvas =
[
    [ "Canvas", "class_canvas.html#aeea65f2bfc2be61bdbcaaa3a67c33185", null ],
    [ "mousePressEvent", "class_canvas.html#ac766a4e369f781943df021b80e5922c4", null ],
    [ "paintEvent", "class_canvas.html#a743fefef4af18260e8d56d95f92618aa", null ],
    [ "setMap", "class_canvas.html#a1c7573f5031e9c97f04699e0ba308bb0", null ],
    [ "droneCollisionDistance", "class_canvas.html#a5226f7b0b1190ff98adb88f2f79c9b5c", null ],
    [ "droneIconSize", "class_canvas.html#a902077fa3f78b9de8c7de3fdb7f1d55a", null ],
    [ "droneImg", "class_canvas.html#a44d7f1a477fa5d0f28f622f8e23166ec", null ],
    [ "mapDrones", "class_canvas.html#a080f2bb0587f29c4b9d3ea31d5ed3a62", null ]
];