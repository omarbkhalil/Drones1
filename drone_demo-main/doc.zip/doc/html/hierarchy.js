var hierarchy =
[
    [ "QMainWindow", null, [
      [ "MainWindow", "class_main_window.html", null ]
    ] ],
    [ "QWidget", null, [
      [ "Canvas", "class_canvas.html", null ],
      [ "Drone", "class_drone.html", null ]
    ] ],
    [ "Vector2D", "class_vector2_d.html", null ]
];