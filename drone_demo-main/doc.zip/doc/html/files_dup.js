var files_dup =
[
    [ "canvas.cpp", "canvas_8cpp.html", null ],
    [ "canvas.h", "canvas_8h.html", "canvas_8h" ],
    [ "drone.cpp", "drone_8cpp.html", null ],
    [ "drone.h", "drone_8h.html", "drone_8h" ],
    [ "main.cpp", "main_8cpp.html", "main_8cpp" ],
    [ "mainwindow.cpp", "mainwindow_8cpp.html", null ],
    [ "mainwindow.h", "mainwindow_8h.html", "mainwindow_8h" ],
    [ "vector2d.cpp", "vector2d_8cpp.html", "vector2d_8cpp" ],
    [ "vector2d.h", "vector2d_8h.html", "vector2d_8h" ]
];